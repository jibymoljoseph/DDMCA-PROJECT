﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcApplication1.Models
{
    public class student
    {
        public int StudentId { get; set; }
        public int userdemoId { get; set; }
        public virtual userdemo userdemo{get;set;}
      [Required]
      [Display(Name = "username")]

      public string Username { get; set;}
      public Gender Genderlist{ get; set;}
    }
public enum Gender
{
    Male,
    Female
}
}