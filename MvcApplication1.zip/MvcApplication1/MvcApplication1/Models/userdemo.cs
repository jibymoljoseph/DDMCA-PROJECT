﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace MvcApplication1.Models
{
    public class userdemo
    {
        
      public  int  userdemoId{ get; set; }
      [Required]
      [Display(Name = "username")]

      public string Username { get; set; }
      [Required]
      [Display(Name = "Password")]
       
          public string Password { get; set; }
    }
}