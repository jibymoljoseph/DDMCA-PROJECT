﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace database.Models
{
    public class user
    {
        public int id {get;set;}
        [Required]
        [Display(Name="username")]
        [RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = "Only Alphabets and Numbers allowed.")]
        public String uname { get; set; }
        [Required ]
        [Display(Name="password")]
        [DataType(DataType.Password,ErrorMessage="invalid")]
        public String password { get; set; }
    }
}