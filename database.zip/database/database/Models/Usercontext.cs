﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
namespace database.Models
{
    public class Usercontext:DbContext
    {
        public Usercontext()
            :base("mycon")
        {
            DropCreateDatabaseIfModelChanges<Usercontext>d=new DropCreateDatabaseIfModelChanges<Usercontext>();
            Database.SetInitializer<Usercontext>(d);
        }
        public DbSet<user>Users{get;set;}
    }

}